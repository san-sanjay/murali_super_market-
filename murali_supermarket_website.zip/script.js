// Simple product data and site logic for Murali Super Market
const STORE = {
  name: "Murali Super Market",
  phone: "8197459203",
  whatsapp: "9986667451",
  address: "Chandapura Anekal Road",
  categories: ["All","Vegetables","Fruits","Beverages","Bakery"],
  products: [
    {id:1,name:"Tomato (1kg)",category:"Vegetables",price:40},
    {id:2,name:"Potato (1kg)",category:"Vegetables",price:30},
    {id:3,name:"Banana (bunch)",category:"Fruits",price:35},
    {id:4,name:"Apple (1kg)",category:"Fruits",price:160},
    {id:5,name:"Orange Juice (1L)",category:"Beverages",price:90},
    {id:6,name:"Mineral Water (1L)",category:"Beverages",price:25},
    {id:7,name:"Whole Wheat Bread",category:"Bakery",price:40},
    {id:8,name:"Croissant",category:"Bakery",price:30}
  ]
};

let cart = [];
const el = s => document.querySelector(s);

function formatINR(n){ return "₹" + n.toFixed(2); }

function init(){
  document.title = STORE.name;
  // categories
  const catBox = el('#categories');
  STORE.categories.forEach(cat => {
    const btn = document.createElement('button');
    btn.textContent = cat;
    btn.dataset.cat = cat;
    if(cat==="All") btn.classList.add('active');
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.categories button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      renderProducts(cat);
    });
    catBox.appendChild(btn);
  });

  el('#search').addEventListener('input', e=> renderProducts(getActiveCategory(), e.target.value));

  renderProducts("All");
  renderCart();
  el('#cartToggle').addEventListener('click', toggleCart);
  el('#clearCart').addEventListener('click', ()=>{ cart=[]; renderCart(); });
  el('#whatsappOrder').addEventListener('click', sendWhatsAppOrder);
  // Set fixed whatsapp order link (header)
  el('#wa-fixed').addEventListener('click', (e)=>{ e.preventDefault(); sendWhatsAppOrder(); });
}

function getActiveCategory(){
  const active = document.querySelector('.categories button.active');
  return active ? active.dataset.cat : "All";
}

function renderProducts(category, q=""){
  const grid = el('#products');
  grid.innerHTML = "";
  const list = STORE.products.filter(p => (category==="All" || p.category===category) &&
    (p.name.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase()))
  );
  list.forEach(p => grid.appendChild(productCard(p)));
  if(list.length===0) grid.innerHTML = "<p style='grid-column:1/-1;color:#6b7280'>No products found.</p>";
}

function productCard(p){
  const div = document.createElement('div'); div.className='card';
  div.innerHTML = `
    <div class="thumb">${svgThumb(p.name)}</div>
    <h4>${p.name}</h4>
    <p class="muted">${p.category}</p>
    <div class="price">${formatINR(p.price)}</div>
    <div class="actions">
      <button class="btn add-btn">Add</button>
      <button class="btn quick-btn">Buy</button>
    </div>
  `;
  div.querySelector('.add-btn').addEventListener('click', ()=>{ addToCart(p); });
  div.querySelector('.quick-btn').addEventListener('click', ()=>{ addToCart(p); sendWhatsAppOrder(); });
  return div;
}

function svgThumb(text){
  // simple colorful SVG placeholder with initials
  const colorList = ["#FFD166","#EF476F","#06D6A0","#118AB2","#06B6D4","#FF7A59"];
  const color = colorList[text.length % colorList.length];
  const initials = text.split(' ').slice(0,2).map(s=>s[0]).join('').toUpperCase();
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 140">
    <rect width="100%" height="100%" rx="10" fill="${color}"></rect>
    <text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" font-size="26" font-family="sans-serif" fill="#082032">${initials}</text>
  </svg>`;
  return svg;
}

function addToCart(p){
  const existing = cart.find(c=>c.id===p.id);
  if(existing) existing.qty++;
  else cart.push({...p, qty:1});
  renderCart();
}

function renderCart(){
  el('#cartList').innerHTML = "";
  let total = 0; let count = 0;
  cart.forEach(item=>{
    const li = document.createElement('li');
    li.innerHTML = `<span>${item.name} x ${item.qty}</span><span>${formatINR(item.price*item.qty)}</span>`;
    el('#cartList').appendChild(li);
    total += item.price*item.qty;
    count += item.qty;
  });
  el('#cartTotal').textContent = formatINR(total);
  el('#cartCount').textContent = count;
  // Persist in localStorage
  localStorage.setItem('murali_cart', JSON.stringify(cart));
}

function toggleCart(){
  const panel = el('#cartPanel');
  panel.style.display = panel.style.display === 'none' || !panel.style.display ? 'block' : 'none';
}

function loadCart(){
  const data = localStorage.getItem('murali_cart');
  if(data) cart = JSON.parse(data);
}

function buildWhatsAppMessage(){
  if(cart.length===0) return `Hello Murali Super Market, I'd like to order some items.`;
  let lines = [];
  lines.push(`Hello Murali Super Market 👋`);
  lines.push(`Delivery Address: ${STORE.address}`);
  lines.push(`Contact: ${STORE.phone}`);
  lines.push(``);
  lines.push(`Order:`);
  cart.forEach(it => lines.push(`${it.name} x ${it.qty} = ₹${(it.price*it.qty).toFixed(2)}`));
  const total = cart.reduce((s,i)=>s+i.price*i.qty,0);
  lines.push(``);
  lines.push(`Total: ₹${total.toFixed(2)}`);
  lines.push(`Please confirm delivery slot and payment method.`);
  return lines.join('\n');
}

function sendWhatsAppOrder(){
  const msg = buildWhatsAppMessage();
  const encoded = encodeURIComponent(msg);
  const wa = `https://wa.me/${STORE.whatsapp}?text=${encoded}`;
  window.open(wa, '_blank');
}

// initialize on load
loadCart();
document.addEventListener('DOMContentLoaded', init);
