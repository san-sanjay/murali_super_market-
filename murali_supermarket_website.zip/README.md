# Murali Super Market — Website Template

This is a simple, **colorful and modern** static website template for *Murali Super Market*.
It includes a product catalog, shopping cart (client-side) and a WhatsApp order button that opens a prefilled message to the store's WhatsApp number (9986667451).

## What's inside
- `index.html` — main page
- `styles.css` — styles
- `script.js` — product data and site logic
- `README.md` — this file

## How to use (quick)
1. Unzip the package.
2. Open `index.html` in your browser to preview locally.
3. To publish for free using **GitHub Pages**:
   - Create a GitHub repository (e.g., `murali-supermarket`)
   - Upload all files (index.html, styles.css, script.js)
   - In repository Settings → Pages, set branch to `main` and folder `/` and save.
   - Your site will be available at `https://yourusername.github.io/your-repo-name/`

## WhatsApp ordering
Clicking **Order via WhatsApp** will open WhatsApp with a prefilled message that includes the cart items and total. The number used: **+91 9986667451**.

## Customize
- Edit `STORE` object in `script.js` to change products, prices, categories, phone numbers, or address.
- Add more product images by replacing the SVG placeholder in `svgThumb` or modifying the productCard function.

---
Built for Murali Super Market — Chandapura Anekal Road
Contact: 8197459203
